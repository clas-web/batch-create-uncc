<?php
/*
Plugin Name: Batch Create - Force Update
Plugin URI: 
Description: On activation, forces the Batch Create plugin to run its update code.
Version: 1.0.0
Author: Crystal Barton
Author URI: http://www.crystalbarton.com
*/

register_activation_hook( __FILE__, array('OAT_Debug' , 'update_batch_create') );

class BatchCreate_ForceUpdate
{
	public static function update_batch_create()
	{
		require_once( $dir = ABSPATH . 'wp-content/plugins/batch-create-uncc/model/model.php' );
		$model = batch_create_get_model();
		$model->create_schema();
	}
}


